/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_short_types.h                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ecaceres <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/17 11:33:38 by ecaceres          #+#    #+#             */
/*   Updated: 2019/08/17 11:33:38 by ecaceres         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_SHORT_TYPES_H
# define FT_SHORT_TYPES_H

# define UINT unsigned int
# define ULNG unsigned long

#endif
